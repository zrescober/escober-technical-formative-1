<link rel="stylesheet" href="<?= base_url('css/style.css') ?>">

<nav>
    <a href="<?= site_url('/') ?>">Home</a>
    <a href="<?= site_url('about') ?>">About</a>
    <a href="<?= site_url('customers') ?>">Customer Accounts</a>
    <a href="<?= site_url('users') ?>">User Accounts</a>
</nav>

<div class="container">
    <div class="card"></div>

<h1>About the POS System</h1>
<p>This basic POS system manages customer and staff account information.</p>
<p>TECHNICAL FORMATIVE ASSESSMENT NO. 1</p>

<a href="<?= site_url('/') ?>">Home</a> |
<a href="<?= site_url('customers') ?>">Customer Accounts</a> |
<a href="<?= site_url('users') ?>">User Accounts</a>