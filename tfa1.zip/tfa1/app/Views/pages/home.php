<link rel="stylesheet" href="<?= base_url('css/style.css') ?>">

<nav>
    <a href="<?= site_url('/') ?>">Home</a>
    <a href="<?= site_url('about') ?>">About</a>
    <a href="<?= site_url('customers') ?>">Customer Accounts</a>
    <a href="<?= site_url('users') ?>">User Accounts</a>
</nav>

<div class="container">
    <div class="card">
        <h1>Basic POS System | TECHNICAL ASSESSMENT 1</h1>
        <p>Welcome to the Point-of-Sale system.</p>
        <p>Welcome to the basic Point-of-Sale system according to the instruction stated by Technical Formative Assessment 1.</p>
    </div>
</div>