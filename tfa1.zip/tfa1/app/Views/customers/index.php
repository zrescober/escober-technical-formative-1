<link rel="stylesheet" href="<?= base_url('css/style.css') ?>">

<nav>
    <a href="<?= site_url('/') ?>">Home</a>
    <a href="<?= site_url('about') ?>">About</a>
    <a href="<?= site_url('customers') ?>">Customer Accounts</a>
    <a href="<?= site_url('users') ?>">User Accounts</a>
</nav>

<div class="container">
    <div class="card"></div>

<h1>Customer Accounts</h1>

<a href="<?= site_url('/') ?>">Home</a> |
<a href="<?= site_url('about') ?>">About</a> |
<a href="<?= site_url('users') ?>">User Accounts</a>

<table border="1" cellpadding="8">
    <tr>
        <th>Full Name</th>
        <th>Email</th>
        <th>Phone</th>
    </tr>

    <?php foreach ($customers as $customer): ?>
        <tr>
            <td><?= esc($customer['full_name']) ?></td>
            <td><?= esc($customer['email']) ?></td>
            <td><?= esc($customer['phone']) ?></td>
        </tr>
    <?php endforeach; ?>
</table>