<link rel="stylesheet" href="<?= base_url('css/style.css') ?>">

<nav>
    <a href="<?= site_url('/') ?>">Home</a>
    <a href="<?= site_url('about') ?>">About</a>
    <a href="<?= site_url('customers') ?>">Customer Accounts</a>
    <a href="<?= site_url('users') ?>">User Accounts</a>
</nav>

<div class="container">
    <div class="card"></div>

<h1>User Accounts</h1>
<p> The list of current users including their username and role.</p>

<a href="<?= site_url('/') ?>">Home</a> |
<a href="<?= site_url('about') ?>">About</a> |
<a href="<?= site_url('customers') ?>">Customer Accounts</a>

<table border="1" cellpadding="8">
    <tr>
        <th>Username</th>
        <th>Full Name</th>
        <th>Role</th>
    </tr>

    <?php foreach ($users as $user): ?>
        <tr>
            <td><?= esc($user['username']) ?></td>
            <td><?= esc($user['full_name']) ?></td>
            <td><?= esc($user['role']) ?></td>
        </tr>
    <?php endforeach; ?>
</table>