<?php

namespace App\Controllers;

class Customers extends BaseController
{
    public function index()
    {
        $customers = [
            [
                'full_name' => 'Ana Reyes',
                'email' => 'ana@example.com',
                'phone' => '0917-111-1111',
            ],
            [
                'full_name' => 'Marco Santos',
                'email' => 'marco@example.com',
                'phone' => '0917-222-2222',
            ],
            [
                'full_name' => 'Leah Cruz',
                'email' => 'leah@example.com',
                'phone' => '0917-333-3333',
            ],
            [
                'full_name' => 'John Dela Torre',
                'email' => 'john@example.com',
                'phone' => '0917-444-4444',
            ],
            [
                'full_name' => 'Mia Garcia',
                'email' => 'mia@example.com',
                'phone' => '0917-555-5555',
            ],
        ];

        return view('customers/index', ['customers' => $customers]);
    }
}