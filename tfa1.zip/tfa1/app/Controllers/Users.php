<?php

namespace App\Controllers;

class Users extends BaseController
{
    public function index()
    {
        $users = [
            ['username' => 'admin', 'full_name' => 'Paolo Mendoza', 'role' => 'Administrator'],
            ['username' => 'cashier01', 'full_name' => 'Rina Flores', 'role' => 'Cashier'],
            ['username' => 'cashier02', 'full_name' => 'Noel Bautista', 'role' => 'Cashier'],
            ['username' => 'inventory01', 'full_name' => 'Ella Ramos', 'role' => 'Inventory Clerk'],
            ['username' => 'manager', 'full_name' => 'Carlo Villanueva', 'role' => 'Store Manager'],
        ];

        return view('users/index', ['users' => $users]);
    }
}